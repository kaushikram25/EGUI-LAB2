using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

namespace TheRecipePartner
{   
    //this code needs to be here for proejct run
    public class Program
    {   //applcations starts from here 
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }
        //this fuction is call startup class for application initialization
        public static IHostBuilder CreateHostBuilder(string[] args) =>Host.CreateDefaultBuilder(args).ConfigureWebHostDefaults(webBuilder => { webBuilder.UseStartup<Startup>(); });
    }
}
