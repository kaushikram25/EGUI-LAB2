﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TheRecipePartner.Models
{
    public class RecipeDataModel
    {
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Please enter recipe name")]
        [Display(Name = "Recipe")]
        public string Recipe { get; set; }


        [Required(ErrorMessage = "Please enter ingredients")]
        [Display(Name = "Ingredients")]
        public string Ingredients { get; set; }


        [Required(ErrorMessage = "Please enter preparation steps")]
        [Display(Name = "Preparations")]
        public string Preparations { get; set; }
    }
    public class RecipeData
    {
        public Guid Id { get; set; }
        public string Recipe { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<string> Preparations { get; set; } = new List<string>();
    }
    public class Ingredient
    {
        public string IngredientName { get; set; }
        public float Quantity { get; set; }
        public string Unit { get; set; }
    }
}
