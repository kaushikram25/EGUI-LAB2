﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace TheRecipePartner.Models
{
    public class Repo
    {
        private static string fileName = "data.json";
        private static string formattedFileName = "formattedData.json";
        private static string staticFileName = "staticData.json";
        private static string FolderName = "JsonData";
        public static List<RecipeDataModel> recipesData = new List<RecipeDataModel>();
        public static List<RecipeData> rfData = new List<RecipeData>();
        public static List<Ingredient> shoppingData = new List<Ingredient>();
        public static IEnumerable<RecipeDataModel> RecipesData
        {
            get { return recipesData = JsonConvert.DeserializeObject<List<RecipeDataModel>>(JSONReadWrite.Read(fileName, FolderName)); }//recipesData
        }
        public static IEnumerable<RecipeData> RecipesFormattedData
        {
            get { return rfData = JsonConvert.DeserializeObject<List<RecipeData>>(JSONReadWrite.Read(formattedFileName, FolderName)); }//rfData
        }
        public static RecipeDataModel GetRecipeByID(Guid id)
        {
            return RecipesData.Where(a => a.Id == id).FirstOrDefault();
        }
        public static RecipeData GetRecipeFormattedDataByID(Guid id)
        {
            return RecipesFormattedData.Where(a => a.Id == id).FirstOrDefault();
        }
        public static void AddDummyData()
        {
            RecipeDataModel recipe = new RecipeDataModel
            {
                Recipe = "Goat Cheese and Chorizo Rolls",
                Ingredients = "Cheese:50 gms\r\nSalt:1 tbsp\r\nRoll:2 pcs",
                Preparations = "Preheat oven to 400° and line two large baking sheets with parchment paper.In a bowl,combine the goat cheese,chorizo and chives." +
                "Season to taste with salt and pepper.\r\n\r\nLay a sheet of phyllo on a clean,dry work surface and brush it with melted butter.Top with two more sheets,lightly buttering each as you go.Cut the layered phyllo into six long rectangles.Place one tablespoon of the goat cheese filling at the base of each rectangle and roll up the phyllo,folding in the sides as you go.Repeat twice more to make 18 rolls total." +
                "\r\n\r\nPlace the rolls on the prepared baking sheets and brush the rolls with butter; bake for 10 minutes, or until golden.Serve hot with chimichurri rojo for dipping."

            };
            Repo.SubmitRecipe(recipe);

            recipe = new RecipeDataModel
            {
                Recipe = "Chocolate Earl Grey Pots de Creme Recipe",
                Ingredients = "Cheese:50 gms\r\nSalt:1 tbsp\r\nRoll:2 pcs",
                Preparations = "Preheat oven to 400° and line two large baking sheets with parchment paper.In a bowl,combine the goat cheese,chorizo and chives." +
                "Season to taste with salt and pepper.\r\n\r\nLay a sheet of phyllo on a clean,dry work surface and brush it with melted butter.Top with two more sheets,lightly buttering each as you go.Cut the layered phyllo into six long rectangles.Place one tablespoon of the goat cheese filling at the base of each rectangle and roll up the phyllo,folding in the sides as you go.Repeat twice more to make 18 rolls total." +
                "\r\n\r\nPlace the rolls on the prepared baking sheets and brush the rolls with butter; bake for 10 minutes, or until golden.Serve hot with chimichurri rojo for dipping."
            };
            Repo.SubmitRecipe(recipe);

            recipe = new RecipeDataModel
            {
                Recipe = "Butter Roll",
                Ingredients = "Cheese, Salt, Roll",
            };
            Repo.SubmitRecipe(recipe);

            recipe = new RecipeDataModel
            {
                Recipe = "Roll Da Fried Veg",
                Ingredients = "Cheese, Salt, Roll",
            };
            Repo.SubmitRecipe(recipe);

            recipe = new RecipeDataModel
            {
                Recipe = "Egg Roll",
                Ingredients = "Cheese, Salt, Roll",
            };
            Repo.SubmitRecipe(recipe);
        }
        public static void SubmitRecipe(RecipeDataModel recipe)
        {

            int insertIndex = 0;
            RecipeData rd = new RecipeData();
            if (recipe.Id != new Guid())
            {
                var existingData = recipesData.FirstOrDefault(a => a.Id == recipe.Id);
                insertIndex = recipesData.IndexOf(existingData);
                recipesData.Remove(existingData);
                recipesData.Insert(insertIndex, recipe);

            }
            else
            {
                recipe.Id = Guid.NewGuid();
                recipesData.Add(recipe);
            }

            string jSONString = JsonConvert.SerializeObject(recipesData);

            JSONReadWrite.Write(fileName, FolderName, jSONString);
            foreach (var item in recipesData)
            {
                FormatData(item);
            }
        }
        private static void FormatData(RecipeDataModel recipe)
        {

            int insertIndex = 0;
            var existingFData = rfData.FirstOrDefault(a => a.Id == recipe.Id);
            insertIndex = rfData.IndexOf(existingFData);
            rfData.Remove(existingFData);

            RecipeData rfD = new RecipeData();
            rfD.Id = recipe.Id;
            rfD.Recipe = recipe.Recipe;

            var preparations = recipe.Preparations?.Split("\r\n\r\n")?.ToList();
            rfD.Preparations = preparations;
            var ingList = new List<Ingredient>();
            var ingredients = recipe.Ingredients?.Split("\r\n")?.ToList();
            foreach (var item in ingredients)
            {
                Ingredient ing = new Ingredient();
                var ingredient = item.Split(":");
                if (ingredient != null && ingredient.Length == 2)
                {
                    ing.IngredientName = ingredient[0];
                    ing.Quantity = (float)Convert.ToDecimal(ingredient[1].TrimStart().Substring(0, ingredient[1].TrimStart().IndexOf(" ")).Trim());
                    ing.Unit = ingredient[1].TrimStart().Substring(ingredient[1].TrimStart().IndexOf(" ")).Trim();
                    ingList.Add(ing);
                }
            }
            rfD.Ingredients = ingList;

            if (insertIndex > -1)
            {
                rfData.Insert(insertIndex, rfD);
            }
            else
            {
                rfData.Add(rfD);
            }

            string jSONString1 = JsonConvert.SerializeObject(rfData);

            JSONReadWrite.Write(formattedFileName, FolderName, jSONString1);

            CreateStaticFile(RecipesFormattedData.ToList());
        }

        public static void RemoveRecipe(Guid id)
        {
            var existingData = recipesData.FirstOrDefault(a => a.Id == id);
            recipesData.Remove(existingData);
            string jSONString = JsonConvert.SerializeObject(recipesData);

            JSONReadWrite.Write(fileName, FolderName, jSONString);

            var existingFData = rfData.FirstOrDefault(a => a.Id == id);
            rfData.Remove(existingFData);
            string jSONStringN = JsonConvert.SerializeObject(rfData);

            JSONReadWrite.Write(formattedFileName, FolderName, jSONStringN);

            CreateStaticFile(RecipesFormattedData.ToList());
        }

        public static void CreateStaticFile(List<RecipeData> recipeDatas)
        {
            StringBuilder jsonStr = new StringBuilder();
            jsonStr.AppendLine("{");
            int counter1 = 1;
            foreach (var item in recipeDatas)
            {
                jsonStr.AppendLine("\"" + item.Recipe + "\":{  ");
                jsonStr.AppendLine("\"recipe\":[");
                int counter = 1;
                if (item.Preparations != null)
                    foreach (var step in item.Preparations)
                    {
                        if (counter < item.Preparations.Count)
                            jsonStr.AppendLine("\"" + step + "\",");
                        else
                            jsonStr.AppendLine("\"" + step + "\"");
                        counter++;
                    }

                jsonStr.AppendLine("],");
                counter = 1;
                foreach (var ingr in item?.Ingredients)
                {
                    if (counter < item?.Ingredients.Count)
                        jsonStr.AppendLine("\"" + ingr.IngredientName + "\":\"" + ingr.Quantity + " " + ingr.Unit + "\",");
                    else
                        jsonStr.AppendLine("\"" + ingr.IngredientName + "\":\"" + ingr.Quantity + " " + ingr.Unit + "\"");
                    counter++;
                }

                if (counter1 < recipeDatas.Count)
                    jsonStr.AppendLine("},");
                else
                    jsonStr.AppendLine("}");

                counter1++;
            }
            jsonStr.AppendLine("}");
            JSONReadWrite.Write(staticFileName, FolderName, jsonStr.ToString());
        }
        public static void LoadStaticFile()
        {
            List<RecipeDataModel> listRecipeData = new List<RecipeDataModel>();
            var data = JSONReadWrite.Read(staticFileName, FolderName);

            var arrReceipes = data.Split("},");

            foreach (var item in arrReceipes)
            {
                RecipeDataModel recipeDataModel = new RecipeDataModel();

                //get name
                recipeDataModel.Recipe = item.Substring(0, (item.Length - item.IndexOf(":")));

                //get preparations
                var prepData = item.Substring((item.Length - item.IndexOf("[")) + 1, (item.Length - item.IndexOf("]")));
                var prepArra = prepData.Split(",");

            }
        }

        public static List<Ingredient> GetShoppingList()
        {
            var list = new List<Ingredient>();
            foreach (var item in RecipesFormattedData)
            {
                foreach (var ingredient in item.Ingredients)
                {
                    list.Add(new Ingredient
                    {
                        IngredientName = ingredient.IngredientName,
                        Quantity = ingredient.Quantity,
                        Unit = ingredient.Unit
                    });
                }
            }

            var ingSum =
                        list
                         .GroupBy(s => new { IngredientName = s.IngredientName.ToLower(), Unit = s.Unit.ToLower() })
                         .Select(g =>
                               new Ingredient
                               {
                                   IngredientName = g.Key.IngredientName,
                                   Unit = g.Key.Unit,
                                   Quantity = g.Sum(x => Convert.ToInt32(x.Quantity)),
                               }
                         );
            return ingSum.ToList();
        }
    }
    public static class JSONReadWrite
    {

        public static string Read(string fileName, string location)
        {
            string root = "wwwroot";
            var path = Path.Combine(
            Directory.GetCurrentDirectory(),
            root,
            location,
            fileName);

            string jsonResult;

            using (StreamReader streamReader = new StreamReader(path))
            {
                jsonResult = streamReader.ReadToEnd();
            }
            return jsonResult;
        }

        public static void Write(string fileName, string location, string jSONString)
        {
            string root = "wwwroot";
            var path = Path.Combine(
            Directory.GetCurrentDirectory(),
            root,
            location,
            fileName);

            using (var streamWriter = File.CreateText(path))
            {
                streamWriter.Write(jSONString);
            }
        }
    }
}
