﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using TheRecipePartner.Models;

namespace TheRecipePartner.Controllers
{
    public class HomeController : Controller
    {
        #region Home Page
        public IActionResult Index()
        {
            if (Repo.RecipesData.Count() == 0)
            {
                //Repo.AddDummyData();
            }
            return View(Repo.RecipesData);
        }
        #endregion

        #region Add Recipe Region
        public IActionResult AddRecipe()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddRecipe(RecipeDataModel recipeModel)
        {
            if (ModelState.IsValid)
            {
                Repo.SubmitRecipe(recipeModel);

                return RedirectToAction("Index");
            }
            else
            {
                return View("AddRecipe");
            }
        }

        #endregion

        public IActionResult EditRecipe(Guid id)
        {
            var data = Repo.GetRecipeByID(id);
            return View(data);
        }

        [HttpPost]
        public IActionResult EditRecipe(RecipeDataModel recipeModel)
        {
            if (ModelState.IsValid)
            {
                Repo.SubmitRecipe(recipeModel);

                return RedirectToAction("RecipeEdit");
            }
            else
            {
                return View("EditRecipe", recipeModel);
            }
        }
        public IActionResult RecipeDetail(Guid id)
        {
            var data = Repo.GetRecipeFormattedDataByID(id);
            return View(data);
        }

        [HttpPost]
        public IActionResult DeleteRecipe(RecipeDataModel recipeModel)
        {

            Repo.RemoveRecipe(recipeModel.Id);

            return RedirectToAction("RecipeDelete");

        }

        #region Recipe Details Region
        public IActionResult RecipeView(Guid id)
        {
            var data = Repo.GetRecipeFormattedDataByID(id);
            return View(data);
        }

        #endregion

        #region Recipe List Region

        [HttpGet]
        public IActionResult RecipeList()
        {
            if (Repo.RecipesData.Count() == 0)
            {
                //Repo.AddDummyData();
            }
            return View(Repo.RecipesData);
        }
        [HttpGet]
        public IActionResult RecipeEdit()
        {
            if (Repo.RecipesData.Count() == 0)
            {
                //Repo.AddDummyData();
            }
            return View(Repo.RecipesData);
        }
        [HttpGet]
        public IActionResult RecipeDelete()
        {
            if (Repo.RecipesData.Count() == 0)
            {
                //Repo.AddDummyData();
            }
            return View(Repo.RecipesData);
        }

        #endregion

        public IActionResult ShoppingList()
        {
            var data = Repo.GetShoppingList();
            return View(data);
        }
    }
}
