using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace TheRecipePartner
{
    public class Startup
    {
        //variable declaration 
        public IConfiguration Config { get; }
        public Startup(IConfiguration config)
        {
            Config = config;
        }
        public void ConfigureServices(IServiceCollection serviceCollection)
        {
            serviceCollection.AddControllersWithViews();
        }

        // this is confiration to run the project
        public void Configure(IApplicationBuilder appBulider, IWebHostEnvironment webEnvVariable)
        {
            //**********************************************//
                        //Basic Intialization//
            //**********************************************//

            //this is to redirect incoming request on https//
            appBulider.UseHttpsRedirection();

            //this is to use static file
            appBulider.UseStaticFiles();

            //this code is to use routing features
            appBulider.UseRouting();

            //this is for url formation
            appBulider.UseEndpoints(endpoints =>{endpoints.MapControllerRoute(name: "default",pattern: "{controller=Home}/{action=Index}/{id?}");});
        }
    }
}
